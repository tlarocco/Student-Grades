
package studentgrades;
import java.text.NumberFormat;
import java.util.Arrays;
import java.util.Scanner;
/**
 * @author Ty Larocco
 */
public class StudentGrades {

    static Scanner sc = new Scanner(System.in);
    public static int a=0, b=0, c=0, d=0, f=0;
    
    public static void main(String[] args) {
        String sid;
        
        System.out.println("Welcome to the grading program.");
        
        sid = getStudentID();
        while (!sid.equalsIgnoreCase("QUIT")) {
            calcGrade(sid);
            sc.nextLine();
            sid=getStudentID();
            
        } //end of while loop
        System.out.println("Thank you for using the grade calculator.");
        System.out.println("You total number of letters grades are as follows.");
        System.out.println("A " + a);
        System.out.println("B " + b);
        System.out.println("C " + c);
        System.out.println("D " + d);
        System.out.println("F " + f);
    }
    
    public static String getStudentID() {
        String sid = "";
        boolean validid = false;
        do {
            try {
                System.out.print("Student ID (enter 'quit' ) to exit: ");
                sid = sc.nextLine();
                
                if (sid.isEmpty()) {
                    System.out.println("Please enter an IC or quit.");
                } else if (sid.equalsIgnoreCase("quit")) {
                    validid = true;
                } else if (!sid.substring(0, 1).equals("A")) {
                    System.out.println("ID must start with A.");
                } else if(sid.length() !=9) {
                    System.out.println("ID must be 'A' followed by 8 digits.");
                } else {
                    long id = Long.parseLong(sid.substring(1));
                    if (id<=0) {
                        System.out.println("ID value after 'A' must be > 0");
                    } else {
                       validid = true;
                    }
                }
                
            } catch (NumberFormatException e) {
               System.out.println("Value after A is illegal.");
            }
        } while (validid == false);
        return sid;
    } //end of getChoice method
    
    public static void calcGrade (String sid) {
        double q1, q2, q3, q4, q5, qM, mT, pR, fE, qaVg, caVg;
        char grade;
        NumberFormat fmt = NumberFormat.getInstance();
        fmt.setMaximumFractionDigits(3);
        fmt.setMinimumFractionDigits(3);
        
        q1 = getScore("Quiz 1");
        q2 = getScore("Quiz 2");
        q3 = getScore("Quiz 3");
        q4 = getScore("Quiz 4");
        q5 = getScore("Quiz 5");
        qM = getScore("Make up quiz");
        mT = getScore("Mid-Term score");
        pR = getScore("Problems score");
        
        
        double[] q = {q1,q2,q3,q4,q5,qM};
        Arrays.sort(q);//sorts q low to high
        qaVg = (q[2] + q[3] + q[4] + q[5])/4.0;
        System.out.println("Quiz average = " + fmt.format(qaVg));
        
        
        if ((qaVg + mT + pR)/3.0 >= 89.5) {
            System.out.println("Congratulations student " + sid + " you do not have to take your final exam you have earned an A in the class!");
        }  else {
            fE = getScore("Final Exam score");
            caVg = (qaVg * .5) + (mT * .15) + (pR * .1) + (fE * .25);
            
            if (caVg >= 89.5) {
                grade = 'A';
                a++;
            } else if ((caVg < 89.5) && (caVg >= 79.5)) {
                grade = 'B';
                b++;
            } else if ((caVg < 79.5) && (caVg >= 69.5)) {
                grade = 'C';
                c++;
            } else if ((caVg < 69.5) && (caVg >=59.5)) {
                grade = 'D';
                d++;
            } else {
                grade = 'F';
                f++;
            }
            System.out.println("Student " + sid + " earned a quiz average of " + qaVg + " a course average of " + caVg + " and a letter grade of: " + grade);
        } 
        
        
    } //end calcgrade
    
    public static double getScore(String qName) {
        double score;
        do {
            try {
                System.out.print(qName + " Score: ");
                score = sc.nextDouble();
                
                if (score < 0) {
                    System.out.println("We only accept values greater than zero.");
                    score = -1;
                } else if (score > 125) {
                    System.out.println("Score must be less than 125.");
                    score = -1;
                }
                
            } catch (Exception e) {
               System.out.println("Illegal score: non-numeric");
               score = -1; //sentinal value
               sc.nextLine();
            }
        } while (score < 0 );    
        return score;
    }
}
